import java.util.Arrays;

public class BlueAstronaut extends Player implements Crewmate {
	
	//variables
	
	private int numTasks;
	private int taskSpeed;
	private int count = 0;
	//Constructors including super constructors
	
	public BlueAstronaut(String name, int susLevel, int numTasks, int taskSpeed) {
		
		super(name,susLevel);
		this.numTasks = numTasks;
		this.taskSpeed = taskSpeed;
	}
	
	public BlueAstronaut(String name) {
		super(name,15);
		this.numTasks = 6;
		this.taskSpeed = 10;
	}
	
	// Methods
	
	// Getters/Setters
	public int getNumTasks( ) {
		//System.out.println(this.numTasks);
		return this.numTasks;
	}
	
	public int getTaskSpeed( ) {
		return this.taskSpeed;
	}
	
	public void completeTask() {
		
		if(this.isFrozen() == true) {
			System.out.println(this.getName() + " is trying to complete a task but is frozen!");
			return;
		}else if(this.count > 0) {
			System.out.println(this.getName() + " has already completed all their tasks.");
			return;
		}else {
			
			if(this.taskSpeed > 20) {
				this.numTasks -= 2;
					
			}else {
				this.numTasks -= 1;
			}
			if(this.numTasks <= 0) {
				this.numTasks = 0;
				count += 1;
				if(count == 1) {
				System.out.println("I have completed all my tasks");
				this.setSusLevel(this.getSusLevel() / 2);
				}
			}
						
		}
	}

	public boolean equals(Object o) {
		if(super.equals(o) && this.getNumTasks() == ((BlueAstronaut)o).getNumTasks()
				&& this.getTaskSpeed() == ((BlueAstronaut)o).getTaskSpeed() ) {
			return true;
		} else {
			return false;
		}
		
	}
	
	public String toString() {
		//System.out.printf("My name is %s, and I have a suslevel  of %d. I am currently %b. I am an %s player!",this.getName(),this.getSusLevel(),this.isFrozen(),this.getSkill());
		if(this.getSusLevel() > 15) {
		System.out.println((super.toString() + " I have " + this.getNumTasks() + " tasks left over.").toUpperCase());
		return ((super.toString() + " I have " + this.getNumTasks() + " tasks left over.").toUpperCase());
		} else {
			System.out.println(super.toString() + " I have " + this.getNumTasks() + " tasks left over.");
		return super.toString() + " I have " + this.getNumTasks() + " tasks left over.";
		}
	}

	@Override 
	public void emergencyMeeting() {

		Player unFrozenPlayers[];
		int length = 0;
		int lengthF = 0;
		// Check if player calling meeting is frozen and terminates method if true
		if (isFrozen() == true) {
			System.out.println(this.getName() + " is trying to call a meeting but is frozen!");
			return;
		}
		
		else {
			
			// Copy the players array
			Player pArr[] = Player.getPlayers();
			
			// Find number of unfrozen players
			for(int i=0; i < pArr.length; i++) {
				
				if(pArr[i].isFrozen() == false && pArr[i] != this) {
				
					length += 1;
					//System.out.println("length loop: " + length);
				}
				
			}
			// initializing length of array
			unFrozenPlayers = new Player[length];
			
			// Populating unFrozenPlayers array 
			for(int i = 0; i < pArr.length; i++) {
				
				if(pArr[i].isFrozen() == true || pArr[i] == this) { //&& pArr[i] != this
					
					lengthF += 1;
					//System.out.println("first state " + lengthF);
					continue;
					
				} else if(pArr[i] != this) { // maybe get rid of the else if conditional? there is a null in UnFrozenPlayers array i think
					
					unFrozenPlayers[i - lengthF] = pArr[i];
					//System.out.println("second state " + lengthF);
				}
				
			}
			
			// Sort Array by Sus Level using comparable interface
			Arrays.sort(unFrozenPlayers);
			// System.out.println(lengthF);
			// If there is a tie for SUS level then nobody is frozen.
				if(unFrozenPlayers.length == 1) {
				
					unFrozenPlayers[0].setFrozen(true);
					System.out.println(unFrozenPlayers[0].getName() + " has been frozen for acting SUS!");
					return;
				}
				else if ( (unFrozenPlayers[unFrozenPlayers.length - 1].getSusLevel() ) == ( (unFrozenPlayers[unFrozenPlayers.length - 2]).getSusLevel() ) ) {
					System.out.println("There is a tie for being the most SUS. No player will be voted off!");
					return;
					
				}else {
				 
					//Freeze player and print statements testing pointer memory functionality
				
					/*Player p2Arr[] = Player.getPlayers();
					Arrays.sort(p2Arr);
					System.out.println(p2Arr[p2Arr.length - 1].getName() + p2Arr[p2Arr.length - 1].isFrozen());
					System.out.println(pArr[pArr.length - 1].getName() + pArr[pArr.length - 1].isFrozen()); */
				
					unFrozenPlayers[unFrozenPlayers.length - 1].setFrozen(true);
				
					System.out.println(unFrozenPlayers[unFrozenPlayers.length - 1].getName() + " has been frozen for acting SUS!");
				
					/*System.out.println(p2Arr[p2Arr.length - 1].getName() + p2Arr[p2Arr.length - 1].isFrozen());

				
					//System.out.println(pArr[pArr.length - 1].getName() + pArr[pArr.length - 1].isFrozen());
					//Player.getPlayers();
					//System.out.println(unFrozenPlayers[unFrozenPlayers.length - 1].isFrozen()); */
				
				}

			
		}
		//Checks to see if game is over and responds accordingly
		gameOver();
		
	}
	
	
	
	
}





