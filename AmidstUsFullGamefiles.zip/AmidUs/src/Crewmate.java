
public interface Crewmate {
	
	public void completeTask();

}
