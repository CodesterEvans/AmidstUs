
public class Gameplay {

	public static void main(String[] args) {

		// Driver file that tests the code. Use the the instructions file
		// on GitHub to follow along and see if the methods are implemented correctly.
		// Check for correct/incorrect outputs using the final pages 
		// of the instructions file.
		
		
		BlueAstronaut bob = new BlueAstronaut("Bob",20,6,30);
		BlueAstronaut heath = new BlueAstronaut("Heath",30,3,21);
		BlueAstronaut albert = new BlueAstronaut("Albert",44,2,0);
		BlueAstronaut angel = new BlueAstronaut("Angel",0,1,0);
		RedAstronaut liam = new RedAstronaut("Liam",19,"experienced");
		RedAstronaut suspiciousPerson = new RedAstronaut("Suspicious Person",100,"expert");
		
		// Game Begins! Welcome to Amidst Us!
		
		liam.sabotage(bob);
		liam.freeze(suspiciousPerson);
		liam.freeze(albert);
		albert.emergencyMeeting();
		suspiciousPerson.emergencyMeeting();
		bob.emergencyMeeting();
		System.out.println(suspiciousPerson.isFrozen());
		heath.completeTask();
		System.out.println(heath.getNumTasks());
		heath.completeTask();
		System.out.println("Heath's num tasks:" + heath.getNumTasks() + " Heath's sus level:" + heath.getSusLevel());
		heath.completeTask();
		liam.freeze(angel);
		System.out.println("Angel's freeze status: " + angel.isFrozen());
		System.out.println("Liam's sus level after freeze fail: " + liam.getSusLevel());
		liam.sabotage(bob);
		liam.sabotage(bob);
		liam.freeze(bob);
		System.out.println("Bob is frozen? " + bob.isFrozen());

		
		// The time to choose between good and evil has come!
		// Uncomment code #1 for a crewmates victory!
		// OR uncomment code #2 for an impostors victory!
		
		// Code #1
		
		/*
		
		angel.emergencyMeeting();
		
		*/ 
		
		// Code #2
		
		/* for(int i = 0; i < 5; i++) {
		liam.sabotage(heath);
		}
		liam.freeze(heath);
		
		*/
		
		// APPENDIX BEGINS HERE
		
		
		//Below are tests I used along the way while programming this file.
		//I like to check my code/save incrementally so I don't waste time. 

		//RedAstronaut joe = new RedAstronaut("joe",9,"Experienced");
		//RedAstronaut cody = new RedAstronaut("cody",10,"Experienced");
		/*BlueAstronaut nick = new BlueAstronaut("Nick",1,5,14);
		BlueAstronaut sam = new BlueAstronaut("Sam",20,3,32);
		BlueAstronaut adam = new BlueAstronaut("Adam",8,4,9);
		RedAstronaut drew = new RedAstronaut("Drew",20,"experienced");
		RedAstronaut lynn = new RedAstronaut("Lynn",16,"Experienced");
		
		nick.toString();
		//System.out.println(drew.equals(drew));
		//cody.setFrozen(true);
		//lynn.setFrozen(true);
		//System.out.println(lynn.skill);
		//System.out.println(drew.getSkill() == drew.getSkill());
		//System.out.println(drew.getSusLevel());
		//System.out.println(cody.getClass());
		cody.setSusLevel(22);
		System.out.println(cody.getSusLevel());
		System.out.println(cody.isFrozen());
		cody.setFrozen(true);
		System.out.println(cody.isFrozen());*/
		
	}

}
