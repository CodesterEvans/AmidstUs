
public interface Impostor {
	
	public void freeze(Player p);
	public void sabotage(Player p);
	
}

