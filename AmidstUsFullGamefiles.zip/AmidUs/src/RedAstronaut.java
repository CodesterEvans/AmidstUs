import java.util.Arrays;
public class RedAstronaut extends Player implements Impostor {

	// Variable
	
	private String skill;
	
	// Super Constructors
	
	public RedAstronaut(String name, int susLevel, String skill) {
		super(name,susLevel);
		
		// Learning about immutable strings
		
		//lowercase skill
		//String tempSkill = skill.toLowerCase();
		String temp = skill.toLowerCase();
		//skill = temp;
		//String temp2 = skill.toLowerCase();
		//this.skill = temp2;*/
		setSkill(temp);
		//System.out.println(this.skill);
		
	}

	public RedAstronaut(String name) {
		
		super(name,15);
		this.skill = "experienced";
		
	}
	
	// Abstract methods implementation
	@Override 
	public void emergencyMeeting() {
		
		Player unFrozenPlayers[];
		int length = 0;
		int lengthF = 0;
		// Check if player calling meeting is frozen and terminates method if true
		if (isFrozen() == true) {
			System.out.println(this.getName() + " is trying to call a meeting but is frozen!");
			return;
		}
		
		else {
			
			// Copy the players array
			Player pArr[] = Player.getPlayers();
			
			// Find number of unfrozen players
			for(int i=0; i < pArr.length; i++) {
				
				if(pArr[i].isFrozen() == false && pArr[i] != this) {
				
					length += 1;
					//System.out.println("length loop: " + length);
				}
				
			}
			// initializing length of array
			unFrozenPlayers = new Player[length];
			
			// Populating unFrozenPlayers array 
			for(int i = 0; i < pArr.length; i++) {
				
				if(pArr[i].isFrozen() == true || pArr[i] == this) { //&& pArr[i] != this
					
					lengthF += 1;
					//System.out.println("first state " + lengthF);
					continue;
					
				} else if(pArr[i] != this) { // maybe get rid of the else if conditional? there is a null in UnFrozenPlayers array i think
					
					unFrozenPlayers[i - lengthF] = pArr[i];
					//System.out.println("second state " + lengthF);
				}
				
			}
			
			// Sort Array by Sus Level using comparable interface
			Arrays.sort(unFrozenPlayers);
			// System.out.println(lengthF);
			// If there is a tie for SUS level then nobody is frozen.
				if(unFrozenPlayers.length == 1) {
				
					unFrozenPlayers[0].setFrozen(true);
					System.out.println(unFrozenPlayers[0].getName() + " has been frozen for acting SUS!");
					return;
				}
				else if ( (unFrozenPlayers[unFrozenPlayers.length - 1].getSusLevel() ) == ( (unFrozenPlayers[unFrozenPlayers.length - 2]).getSusLevel() ) ) {
					System.out.println("There is a tie for being the most SUS. No player will be voted off!");
					return;
					
				}else {
				 
					//Freeze player and print statements testing pointer memory functionality
				
					/*Player p2Arr[] = Player.getPlayers();
					Arrays.sort(p2Arr);
					System.out.println(p2Arr[p2Arr.length - 1].getName() + p2Arr[p2Arr.length - 1].isFrozen());
					System.out.println(pArr[pArr.length - 1].getName() + pArr[pArr.length - 1].isFrozen()); */
				
					unFrozenPlayers[unFrozenPlayers.length - 1].setFrozen(true);
				
					System.out.println(unFrozenPlayers[unFrozenPlayers.length - 1].getName() + " has been frozen for acting SUS!");
				
					/*System.out.println(p2Arr[p2Arr.length - 1].getName() + p2Arr[p2Arr.length - 1].isFrozen());

				
					//System.out.println(pArr[pArr.length - 1].getName() + pArr[pArr.length - 1].isFrozen());
					//Player.getPlayers();
					//System.out.println(unFrozenPlayers[unFrozenPlayers.length - 1].isFrozen()); */
				
				}

			
		}
		//Checks to see if game is over and responds accordingly
		gameOver();
		
	}
	@Override
	public void freeze(Player p) {
		
		// Check if the player calling meeting is frozen or if passed in player is an impostor or frozen. Then terminates method if any are true
		if (this.isFrozen() == true || p.isFrozen() == true || p instanceof Impostor) {
			System.out.println(this.getName() + " is trying to freeze but is frozen or the person they are trying to freeze is frozen or an impostor");
			return;
			
			// The bulk of the method
		} else {
			
			// If the calling impostors sus level is less 
			// than the crewmate's then the crewmate is frozen!
			if(this.getSusLevel() < p.getSusLevel()) {
				
				p.setFrozen(true);
				System.out.println(this.getName() + " has frozen " + p.getName() + "!");
			// If impostors sus level is equal or greater than the crewmates
			// then that is pretty sus of them! Double the impostors Sus level!
			} else {
				
				this.setSusLevel(this.getSusLevel() * 2);
				System.out.println("Freeze failed! " + this.getName() + "'s sus level will be doubled!");
			}
		}
		
		//Checks to see if game is over and responds accordingly
		gameOver();
	}
	@Override
	public void sabotage(Player p) {
		
		// Check if the player calling meeting is frozen or if passed in player is an impostor or frozen. Then terminates method if any are true
		if (this.isFrozen() == true || p.isFrozen() == true || p instanceof Impostor) {
			System.out.println(this.getName() + " is trying to sabotage but is frozen or the person they are trying to sabotage is frozen or an impostor");
			return;
			
		} else {
			
			if(this.getSusLevel() < 20) {
				p.setSusLevel((int)(p.getSusLevel() * 1.5));
				System.out.println("Through shifty maneuvers and cunning words, " + this.getName() + 
				" has increased " + p.getName() + "'s sus level by 50% to " + p.getSusLevel());
			} else {
				p.setSusLevel((int)(p.getSusLevel() * 1.25));
				System.out.println(this.getName() + " has increased "
				+ p.getName() + "'s sus level by 25% to " + p.getSusLevel());
			}
		}
	}
	/* The instructions say to pass in an object to the equals method; however, 
	I can't tell if I am supposed to learn how to compare generic objects or if it was a 
	typo in the instructions and I need to compare Red astronauts. I had decided to compare player-objects instead as a compromise
	but then noticed that players do not have a "skill" variable. The assignment instructions in this whole course including the grader
	appear unedited so I just went ahead only compared RedAstronatuts
	
	UPDATE: I figured out that the Player.java super class has an equals method for an Object o. I used casting to make o.skill work */
	
	public boolean equals(Object o) {
		
		if(super.equals(o) == true && this.skill == ((RedAstronaut)o).getSkill()) {
			return true;
		} else {
		
		/*if(p instanceof RedAstronaut &&( this.getName() == p.getName() )&&( this.isFrozen() == p.isFrozen() )
				&&( this.getSusLevel() == p.getSusLevel() ) &&(this.skill == p.skill)) {
			
			return true;
			
		} else {
			
			return false;
		}*/
		return false;
		}
	}
	
	
	public String toString() {
		//System.out.printf("My name is %s, and I have a suslevel  of %d. I am currently %b. I am an %s player!",this.getName(),this.getSusLevel(),this.isFrozen(),this.getSkill());
		if(this.getSusLevel() > 15) {
		System.out.println((super.toString() + " I am an " + this.getSkill() + " player!").toUpperCase());
		return (super.toString() + " I am an " + this.getSkill() + " player!").toUpperCase();
		} else {
		System.out.println(super.toString() + " I am an " + this.getSkill() + " player!");
		return super.toString() + " I am an " + this.getSkill() + " player!";
		}
	}
	
	//Getters & Setters
	public String getSkill() {
		
		return (this.skill);
	}
	
	public void setSkill(String skill) { 
		
		this.skill = skill;
	}
	
}



